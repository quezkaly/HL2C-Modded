INFO_PLAYER_SPAWN = { Vector( -3931, 6784, 5 ), 0 }

NEXT_MAP = "d3_c17_10b"


-- Player spawns
function hl2cPlayerSpawn( ply )

	ply:Give( "weapon_hands" )

end
hook.Add( "PlayerSpawn", "hl2cPlayerSpawn", hl2cPlayerSpawn )


-- Initialize entities
function hl2cMapEdit()

	ents.FindByName( "player_spawn_items_maker" )[ 1 ]:Remove()

	local barney = ents.Create( "npc_barney" )
	barney:SetPos( Vector( -3588, 6994, 1 ) )
	barney:SetAngles( Angle( 0, -90, 0 ) )
	barney:SetName( "barney" )
	barney:SetKeyValue( "additionalequipment", "weapon_ar2" )
	barney:SetKeyValue( "spawnflags", "4" )
	barney:SetKeyValue( "squadname", "player_squad" )
	barney:Spawn()
	barney:Activate()

end
hook.Add( "MapEdit", "hl2cMapEdit", hl2cMapEdit )


-- Accept input
function hl2cAcceptInput( ent, input )

	if ( !game.SinglePlayer() && ( ent:GetName() == "first_turret_relay" ) && ( string.lower( input ) == "trigger" ) ) then
	
		ents.FindByName( "barney" )[ 1 ]:SetLastPosition( Vector( -3305.125488, 7036.965332, 128.03125 ) )
		ents.FindByName( "barney" )[ 1 ]:SetSchedule( SCHED_FORCED_GO_RUN )
	
	end

	if ( !game.SinglePlayer() && ( ent:GetName() == "barney_nexusahead_lcs_relay" ) && ( string.lower( input ) == "trigger" ) ) then
	
		ents.FindByName( "barney" )[ 1 ]:SetPos( Vector( -2930, 6463, 257 ) )
		ents.FindByName( "barney" )[ 1 ]:SetLastPosition( Vector( -2579.804443, 6482.348633, 512.03125 ) )
		ents.FindByName( "barney" )[ 1 ]:SetSchedule( SCHED_FORCED_GO_RUN )
	
	end

	if ( !game.SinglePlayer() && ( ent:GetName() == "detected_relay" ) && ( string.lower( input ) == "trigger" ) ) then
	
		ents.FindByName( "barney" )[ 1 ]:SetLastPosition( Vector( -2842.493408, 8015.20752, 128.03125 ) )
		ents.FindByName( "barney" )[ 1 ]:SetSchedule( SCHED_FORCED_GO_RUN )
	
	end

end
hook.Add( "AcceptInput", "hl2cAcceptInput", hl2cAcceptInput )
