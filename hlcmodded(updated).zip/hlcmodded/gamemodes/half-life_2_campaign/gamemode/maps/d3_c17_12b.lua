NEXT_MAP = "d3_c17_13"


-- Player spawns
function hl2cPlayerSpawn( ply )

	ply:Give( "weapon_hands" )

end
hook.Add( "PlayerSpawn", "hl2cPlayerSpawn", hl2cPlayerSpawn )


-- Initialize entities
function hl2cMapEdit()

	ents.FindByName( "player_spawn_items_maker" )[ 1 ]:Remove()

	if ( !game.SinglePlayer() ) then
	
		ents.FindByName( "entry_ceiling_breakable_1" )[ 1 ]:Remove()
		ents.FindByName( "entry_ceiling_debris_1" )[ 1 ]:Remove()
		ents.FindByName( "entry_ceiling_debris_clip_1" )[ 1 ]:Remove()
		ents.FindByName( "entry_ceiling_exp_1" )[ 1 ]:Remove()
		ents.FindByName( "entry_ceiling_exp_1" )[ 2 ]:Remove()
	
	end

end
hook.Add( "MapEdit", "hl2cMapEdit", hl2cMapEdit )
