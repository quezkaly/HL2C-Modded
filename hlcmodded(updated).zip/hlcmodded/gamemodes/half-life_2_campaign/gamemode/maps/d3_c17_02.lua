NEXT_MAP = "d3_c17_03"

TRIGGER_CHECKPOINT = {
	{ Vector( -5552, -5706, -4 ), Vector( -5505, -5537, 103 ) }
}

TRIGGER_DELAYMAPLOAD = { Vector( -5203, -4523, 0 ), Vector( -5143, -4483, 121 ) }


-- Player spawns
function hl2cPlayerSpawn( ply )

	ply:Give( "weapon_hands" )

end
hook.Add( "PlayerSpawn", "hl2cPlayerSpawn", hl2cPlayerSpawn )


-- Initialize entities
function hl2cMapEdit()

	ents.FindByName( "global_newgame_template_ammo" )[ 1 ]:Remove()
	ents.FindByName( "global_newgame_template_base_items" )[ 1 ]:Remove()
	ents.FindByName( "global_newgame_template_local_items" )[ 1 ]:Remove()

end
hook.Add( "MapEdit", "hl2cMapEdit", hl2cMapEdit )
