-- Таблицы для отслеживания спавна объектов для каждого игрока
local weaponsSpawned = {}
local entitiesSpawned = {}

-- Функция для создания оружия
local function SpawnWeaponNearPlayer(player)
    if not IsValid(player) or player:IsBot() then return end -- Проверка на действительность игрока

    local steamID = player:SteamID()
    -- Проверка, было ли оружие уже создано для данного игрока
    if weaponsSpawned[steamID] then return end
    weaponsSpawned[steamID] = true

    -- Создание оружия (пример: pistol)
    local weapon = ents.Create("wep_daun_hmcd_mp7")
    if not IsValid(weapon) then return end -- Проверка на действительность оружия

    -- Положение оружия - немного от игрока, но на земле
    local pos = player:GetPos() + player:GetForward() * 50 + Vector(0, 0, 10)
    weapon:SetPos(pos)
    weapon:Spawn()

    -- Создание 120 магазинов оружия mp7
    for i = 1, 120 do
        local weapon = ents.Create("SMG1")
        if IsValid(weapon) then
            -- Положение оружия - случайное место в пределах радиуса от игрока
            local pos = player:GetPos() + Vector(math.random(-500, 500), math.random(-500, 500), 10)
            weapon:SetPos(pos)
            weapon:Spawn()
        end
    end
end


-- Функция для создания сущностей
local function SpawnEntityNearPlayer(player)
    if not IsValid(player) or player:IsBot() then return end -- Проверка на действительность игрока

    local steamID = player:SteamID()
    -- Проверка, были ли сущности уже созданы для данного игрока
    if entitiesSpawned[steamID] then return end
    entitiesSpawned[steamID] = true

    -- Создание сущности (пример: prop_physics)
    local entity = ents.Create("prop_physics")
    if not IsValid(entity) then return end -- Проверка на действительность сущности

    -- Положение сущности - немного от игрока, но на земле
    local pos = player:GetPos() + player:GetForward() * 100 + Vector(0, 0, 10)
    entity:SetPos(pos)
    entity:SetModel("models/props_c17/oildrum001.mdl") -- Пример модели сущности
    entity:Spawn()
end

-- Хук для создания оружия при возрождении игрока
hook.Add("PlayerSpawn", "SpawnWeapon", function(player)
    if player:IsBot() then return end -- Игнорирование спавна для ботов
    SpawnWeaponNearPlayer(player)
end)