if ( SERVER ) then
	AddCSLuaFile()
else
	killicon.AddFont( "wep_jack_hmcd_revolver", "HL2MPTypeDeath", "1", Color( 255, 0, 0 ) )
	SWEP.WepSelectIcon=surface.GetTextureID("vgui/wep_jack_hmcd_revolver")
end
SWEP.Base = "wep_jack_hmcd_firearm_base"
SWEP.PrintName		= "Manurhin MR96"
SWEP.Instructions	= "This is an inexpensive 6-round revolver firing .38-special.\n\nLMB to fire.\nRMB to aim.\nRELOAD to reload.\nShot placement counts.\nCrouching helps stability.\nBullets can ricochet and penetrate."
SWEP.Primary.ClipSize			= 6
SWEP.Primary.DefaultClip		= SWEP.Primary.ClipSize
SWEP.ViewModel		= "models/weapons/v_pist_jeagle.mdl"
SWEP.WorldModel		= "models/weapons/w_pist_jeagle.mdl"
SWEP.Spawnable = true
SWEP.Category = "Homicide: Firearms"
SWEP.ViewModelFlip=false
SWEP.Damage=40
SWEP.SprintPos=Vector(3,0,-12)
SWEP.SprintAng=Angle(70,0,0)
SWEP.AimPos=Vector(-1.75,0,.4)
SWEP.ReloadTime=5
SWEP.ReloadRate=.5
SWEP.ReloadSound="snd_jack_hmcd_rvreload.wav"
SWEP.Primary.Ammo = "357"
SWEP.AmmoType="357"
SWEP.TriggerDelay=.175
SWEP.CycleTime=.175
SWEP.Recoil=1
SWEP.Supersonic=false
SWEP.Accuracy=.99
SWEP.ShotPitch=90
SWEP.ENT="ent_jack_hmcd_revolver"
SWEP.CycleType="revolving"
SWEP.ReloadType="clip"
SWEP.CustomColor=Color(50,50,50,255)
SWEP.HolsterSlot=2
SWEP.CarryWeight=1500

if(CLIENT)then
	function SWEP:DrawWorldModel()
		local Pos,Ang=self.Owner:GetBonePosition(self.Owner:LookupBone("ValveBiped.Bip01_R_Hand"))
		if(self.DatWorldModel)then
			if((Pos)and(Ang))then
				self.DatWorldModel:SetRenderOrigin(Pos+Ang:Forward()*-0.45+Ang:Right()*1+Ang:Up()*0.5)
				Ang:RotateAroundAxis(Ang:Up(),180)
				Ang:RotateAroundAxis(Ang:Right(),185)
				Ang:RotateAroundAxis(Ang:Forward(),0)
				self.DatWorldModel:SetRenderAngles(Ang)
				self.DatWorldModel:DrawModel()
			end
		else
			self.DatWorldModel=ClientsideModel("models/weapons/w_pist_jeagle.mdl")
			self.DatWorldModel:SetPos(self:GetPos())
			self.DatWorldModel:SetParent(self)
			self.DatWorldModel:SetNoDraw(true)
		end
	end
end