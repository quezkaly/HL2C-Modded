local EntityMeta = FindMetaTable("Entity")
game.AddParticles("particles/pcfs_jack_muzzleflashes.pcf")
game.AddParticles("particles/pcfs_jack_explosions_small3.pcf")
game.AddParticles("particles/pcfs_jack_explosions_incendiary2.pcf")

function EntityMeta:NearGround()
	return util.QuickTrace(self:GetPos()+vector_up*10,-vector_up*50,{self}).Hit
end

function EntityMeta:CanSee(ent)
	local pos,filterent=ent,nil
	if(type(ent)=="Entity")then pos=ent:LocalToWorld(ent:OBBCenter());filterent=ent end
	local Tr={
		start=self:LocalToWorld(self:OBBCenter()),
		endpos=pos,
		filter={self,filterent}
	}
	return !Tr.Hit
end

function EntityMeta:ExplodeIED()
	local Pos,Ground,Attacker,SplodeType,Mul=self:LocalToWorld(self:OBBCenter())+Vector(0,0,5),self:NearGround(),self.IEDAttacker,HMCD_ExplosiveType(self),1
	if(self:IsPlayer())then
		Attacker=self
		SplodeType=1
		self:KillSilent()
		SplodeType=2
	end
	if(SplodeType==3)then
		if(Ground)then
			ParticleEffect("pcf_jack_incendiary_ground_sm2",Pos,vector_up:Angle())
		else
			ParticleEffect("pcf_jack_incendiary_air_sm2",Pos,VectorRand():Angle())
		end
	else
		if(Ground)then
			ParticleEffect("pcf_jack_groundsplode_small3",Pos,vector_up:Angle())
		else
			ParticleEffect("pcf_jack_airsplode_small3",Pos,VectorRand():Angle())
		end
	end
	local Foom=EffectData()
	Foom:SetOrigin(Pos)
	util.Effect("explosion",Foom,true,true)
	local Flash=EffectData()
	Flash:SetOrigin(Pos)
	Flash:SetScale(2)
	util.Effect("eff_jack_hmcd_dlight",Flash,true,true)
	timer.Simple(.01,function()
		if not(SplodeType==3)then
			sound.Play("snd_jack_hmcd_explosion_debris.mp3",Pos,85,math.random(90,110))
			sound.Play("snd_jack_hmcd_explosion_far.wav",Pos-vector_up,140,100)
			sound.Play("snd_jack_hmcd_debris.mp3",Pos+vector_up,85,math.random(90,110))
		end
		for i=0,10 do
			local Tr=util.QuickTrace(Pos,VectorRand()*math.random(10,150),{self})
			if(Tr.Hit)then util.Decal("Scorch",Tr.HitPos+Tr.HitNormal,Tr.HitPos-Tr.HitNormal) end
		end
	end)
	timer.Simple(.02,function()
		if(SplodeType==3)then
			sound.Play("snd_jack_hmcd_explosion_close.wav",Pos,70,100)
			sound.Play("snd_jack_firebomb.wav",Pos,80,100)
		else
			sound.Play("snd_jack_hmcd_explosion_close.wav",Pos,80,100)
			sound.Play("snd_jack_hmcd_explosion_close.wav",Pos+vector_up,80,100)
			sound.Play("snd_jack_hmcd_explosion_close.wav",Pos-vector_up,80,100)
		end
	end)
	timer.Simple(.03,function()
		if not(SplodeType==3)then
			if not(SplodeType==2)then
				for key,ent in pairs(ents.FindInSphere(Pos,75))do
					if((ent!=self)and(ent:GetClass()=="func_breakable")and(ent:CanSee(Pos)))then
						ent:Fire("break","",0)
					elseif((ent!=self)and(HMCD_IsDoor(ent))and not(ent:GetNoDraw())and(ent:CanSee(Pos)))then
						HMCD_BlastThatDoor(ent)
					end
				end
			else
				local Poof=EffectData()
				Poof:SetOrigin(Pos)
				Poof:SetScale(1)
				util.Effect("eff_jack_hmcd_shrapnel",Poof,true,true)
			end
		else
			local Fire=ents.Create("ent_jack_hmcd_fire")
			Fire.Initiator=Attacker
			Fire:SetPos(Pos)
			Fire:Spawn()
			Fire:Activate()
		end
	end)
	timer.Simple(.04,function()
		if not(SplodeType==3)then
			util.BlastDamage(self,Attacker,Pos,150*Mul,75*Mul)
			local shake=ents.Create("env_shake")
			shake:SetPos(Pos)
			shake:SetKeyValue("amplitude",tostring(100))
			shake:SetKeyValue("radius",tostring(200))
			shake:SetKeyValue("duration",tostring(1))
			shake:SetKeyValue("frequency",tostring(200))
			shake:SetKeyValue("spawnflags",bit.bor(4,8,16))
			shake:Spawn()
			shake:Activate()
			shake:Fire("StartShake","",0)
			SafeRemoveEntityDelayed(shake,2) -- don't clutter up the world
			local shake2=ents.Create("env_shake")
			shake2:SetPos(Pos)
			shake2:SetKeyValue("amplitude",tostring(100))
			shake2:SetKeyValue("radius",tostring(400))
			shake2:SetKeyValue("duration",tostring(1))
			shake2:SetKeyValue("frequency",tostring(200))
			shake2:SetKeyValue("spawnflags",bit.bor(4))
			shake2:Spawn()
			shake2:Activate()
			shake2:Fire("StartShake","",0)
			SafeRemoveEntityDelayed(shake2,2) -- don't clutter up the world
			util.BlastDamage(self,Attacker,Pos,500*Mul,50*Mul)
		end
	end)
	timer.Simple(.05,function()
		if(SplodeType==2)then
			local Shrap=DamageInfo()
			Shrap:SetAttacker(Attacker)
			if(IsValid(self))then
				Shrap:SetInflictor(self)
			else
				Shrap:SetInflictor(game.GetWorld())
			end
			Shrap:SetDamageType(DMG_BUCKSHOT)
			Shrap:SetDamage(100*Mul)
			util.BlastDamageInfo(Shrap,Pos,750*Mul)
		end
		if not(self:IsPlayer())then SafeRemoveEntity(self) end
	end)
	timer.Simple(.1,function()
		for key,rag in pairs(ents.FindInSphere(Pos,750))do
			if((rag:GetClass()=="prop_ragdoll")or(rag:IsPlayer()))then
				for i=1,20 do
					local Tr=util.TraceLine({start=Pos,endpos=rag:GetPos()+VectorRand()*50})
					if((Tr.Hit)and(Tr.Entity==rag))then util.Decal("Blood",Tr.HitPos+Tr.HitNormal,Tr.HitPos-Tr.HitNormal) end
				end
			end
		end
	end)
end

local FragMats={
	"canister","chain","combine_metal","floating_metal_barrel","grenade","metal","metal_barrel","metal_bouncy","Metal_Box",
	"metal_seafloorcar","metalgrate","metalpanel","metalvent","metalvehicle","paintcan","roller","slipperymetal","solidmetal","weapon",
	"glass","combine_glass","computer"
}

function HMCD_ExplosiveType(self)
	-- 1 = inert (default HE), 2 = fragmentary, 3 = incendiary
	if not(IsValid(self))then return 1 end
	local Phys=self:GetPhysicsObject()
	if(IsValid(Phys))then
		if(table.HasValue(HMCD_FlammableModels,string.lower(self:GetModel())))then return 3 end
		local Mass,Volume,Mat,MassRequirement=Phys:GetMass(),Phys:GetVolume(),Phys:GetMaterial(),5
		if((Mat=="weapon")or(Mat=="computer"))then MassRequirement=20 end
		local Density=Mass/(self:OBBMaxs():Length())
		--JackaPrint(Mat,Volume,Mass,Density)
		if((Mass)and(tonumber(Mass))and(Mass>=MassRequirement)and(Mass<=100)and(Volume)and(tonumber(Volume))and(Volume>=300)and(Volume<=30000)and(Density>=.38))then
			if(table.HasValue(FragMats,Mat))then return 2 end
		end
	end
	return 1
end

function HMCD_BlastThatDoor(ent)
	local Moddel,Pozishun,Ayngul,Muteeriul,Skin=ent:GetModel(),ent:GetPos(),ent:GetAngles(),ent:GetMaterial(),ent:GetSkin()
	sound.Play("Wood_Crate.Break",Pozishun,60,100)
	sound.Play("Wood_Furniture.Break",Pozishun,60,100)
	ent:Fire("open","",0)
	ent:Fire("kill","",.1)
	if((Moddel)and(Pozishun)and(Ayngul))then
		local Replacement=ents.Create("prop_physics")
		Replacement.HmcdSpawned=true
		Replacement:SetModel(Moddel);Replacement:SetPos(Pozishun);Replacement:SetAngles(Ayngul)
		if(Muteeriul)then Replacement:SetMaterial(Muteeriul) end
		if(Skin)then Replacement:SetSkin(Skin) end
		Replacement:Spawn()
		Replacement:Activate()
		timer.Simple(3,function()
			if(IsValid(Replacement))then Replacement:SetCollisionGroup(COLLISION_GROUP_WEAPON) end
		end)
	end
end

function HMCD_WhomILookinAt(ply,cone,dist)
	local CreatureTr,ObjTr,OtherTr=nil,nil,nil
	for i=1,(150*cone) do
		local Vec=(ply:GetAimVector()+VectorRand()*cone):GetNormalized()
		local Tr=util.QuickTrace(ply:GetShootPos(),Vec*dist,{ply})
		if((Tr.Hit)and not(Tr.HitSky)and(Tr.Entity))then
			local Ent,Class=Tr.Entity,Tr.Entity:GetClass()
			if((Ent:IsPlayer())or(Ent:IsNPC()))then
				CreatureTr=Tr
			elseif((Class=="prop_physics")or(Class=="prop_physics_multiplayer")or(Class=="prop_ragdoll")or(Ent.IsLoot))then
				ObjTr=Tr
			else
				OtherTr=Tr
			end
		end
	end
	if(CreatureTr)then return CreatureTr.Entity,CreatureTr.HitPos,CreatureTr.HitNormal end
	if(ObjTr)then return ObjTr.Entity,ObjTr.HitPos,ObjTr.HitNormal end
	if(OtherTr)then return OtherTr.Entity,OtherTr.HitPos,OtherTr.HitNormal end
	return nil,nil,nil
end

function HMCD_IsDoor(ent)
	local Class=ent:GetClass()
	return ((Class=="prop_door")or(Class=="prop_door_rotating")or(Class=="func_door")or(Class=="func_door_rotating")or(Class=="func_breakable"))
end

HMCD_FlammableModels={
	"models/props_c17/canister01a.mdl",
	"models/props_c17/canister02a.mdl",
	"models/props_c17/oildrum001_explosive.mdl",
	"models/props_junk/gascan001a.mdl",
	"models/props_junk/metalgascan.mdl",
	"models/props_junk/propane_tank001a.mdl",
	"models/props_junk/propanecanister001a.mdl"
}